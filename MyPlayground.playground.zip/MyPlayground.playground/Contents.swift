import UIKit

var str = "Hello, playground"

//Creating an array
var myArray: [String] = ["My", "Array"]

var myArray1 = [Int]()

//Creating a Set

var mySet = Set<Int>()

var mySet1: Set<String> = ["Rock", "Roll"]

print(mySet1)


mySet1.insert("Fossil")

print(mySet1)

//Dictionaries

var myDict: [String:String] = ["Sam" : "Blup", "Stand" : "up"]

var myDict1: Dictionary<String,Int> = ["Sam" : 3, "Itai" : 4]

var myDict2 = [Int:Int]()

myDict2[2] = 3


print(myDict)
